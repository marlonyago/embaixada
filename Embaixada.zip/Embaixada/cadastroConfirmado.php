<?php
    require_once("conecta.php");

    $nome		= $_GET['nome'];
	$email		= $_GET['email'];	
    $sql = "UPDATE usuarios SET ativo='1' WHERE email='$email'";
    $ativar = mysqli_query($con,$sql);

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Documento sem título</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/normalize.css">
<link rel="stylesheet" href="assets/css/bootstrap-grid.min.css">

</head>
<body class="telas">

	
<div class="container">
  <div class="row">
	  <div class="col">
		  <div class="logo">
	        <img src="assets/Imgens/logo.png" alt="" >
		  </div>
	  </div>  
  </div>	
</div>

    
  <section class="container">
		<article class="row">
	  <div class="col">
		  
	    <div class="login">
		   
            
           
            
 
            
            <div class="ok">
              <h1>Seu cadastro foi Confirmado</h1>
              <h2> Seja bem vindo <?= $nome ?></h2>
                <br>
                <a href="index.php">Fazer Login</a>
            </div> 
            
            
           
            
            
            
		</div>
		  
		  
		  
	  </div>
	</article>
  </section>	


	
<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
