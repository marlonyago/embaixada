<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Documento sem título</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/normalize.css">
<link rel="stylesheet" href="assets/css/bootstrap-grid.min.css">
</head>

<body class="telas">
    
    
	
<div class="container">
  <div class="row">
	  <div class="col">
		  <div class="logo">
	        <img src="assets/Imgens/logo.png" alt="" >
		  </div>
	  </div>  
  </div>	
</div>
  <section class="container">
		<article class="row">
	  <div class="col">
		  
	    <div class="login" style="margin-bottom: 150px;">         
    <?php if(isset($_GET["cod"]) == 1 ){ ?>
            
                <div class="ok">
                  <h1>Já existe uma conta com esse E-mail</h1>
                  <h2> Caso tenha esquecido, clica <a href="redefinir.php">aqui </a> para redefinir senha</h2>
                </div> 
            <?php }elseif(isset($_GET["cod"]) == 2 ){ ?>
            
                  <div class="ok">
                   <h1>Ocorreu um erro ao efetuar seu cadastro</h1>
                   <h2> Favor entrar em contato ccontato@embaixada.com.br</h2>
                 </div>            
            
            <?php } ?>  
            <form action="enviar.php" name="cadastro" id="cadastro" method="post">
			 <input type="text" required placeholder="NOME" name="nome" id="nome">
			 <input type="text" required placeholder="SOBRENOME" name="sobrenome" id="sobrenome">
			 <input type="email" required placeholder="EMAIL" name="email" id="email">
			 <input type="tel" required placeholder="TELEFONE" id="telefone" maxlength="15" name="telefone" >
			 <input type="password" required placeholder="SENHA" name="senha" id="senha">
			 <input type="password" required placeholder="CONFIRMAR SENHA" name="senhac" id="senhac">
               
               <div class="check">
                  
                   <input type="checkbox" name="termos" value="true" required title="Para continuar tem qu aceitar os termos"><span></span>                    
			     
                   <p >Aceitar os termos de uso</p>
               </div>
               
			<button type="submit">ENTRAR</button>
		   </form>
		</div>
		  

	  </div>
	</article>
  </section>	
    

<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/jquery.mask.min.js"></script>
<script src="assets/js/script.js"></script>    
</body>
</html>
