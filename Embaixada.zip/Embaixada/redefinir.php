<?php
require_once("conecta.php");
session_start();

  $email = $_POST["email"];




  $sql_verifica = "SELECT * FROM usuarios WHERE email='$email'";
  $verificar = mysqli_query($con,$sql_verifica);  
  $contar = mysqli_num_rows($verificar);



  switch($contar){
    case 0:
        $resp = "Esse E-mail não está cadastrado";
        header("location:redefinirsenha.php?cod=$resp");
    break;
          
    case  1:
       envio($email);
    break;
          
          
      default:
        $resp = "Houve um erro favor entrar em contato";
        header("location:redefinirsenha.php?cod=$resp");
          
  }


function envio($email){
        
  $urlSite = "http://prof.cd6host.com/Embaixada" ;      
  $emailenviar = $email;
  $destino = $emailenviar;
  $assunto = "Redifinir Senha";
  $arquivo = "Olá $email<br/><br/>
			Para redefinir a nova senha basta clicar no link abaixo:<br/>
			<a href='$urlSite/novasenha.php?email=$email'>Clique aqui para confirmar seu cadastro</a><br/><br/>
			Se não tiver sido você a redefinir a senha, apenas desconsidere esta mensagem<br/><br/>
			Obrigado!";
 

  $headers  = 'MIME-Version: 1.0' . "\r\n";
      $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
      $headers .= 'From: Embaixada <$email>';
  //$headers .= "Bcc: $EmailPadrao\r\n";
   
  $enviaremail = mail($destino, $assunto, $arquivo, $headers);
      
      
  if($enviaremail){
        header("location:confirmar-senha-ok.php");   
  
  } else {
       header("location:confirmar-senha-erro.php"); 
  }
    

    
    
    
    
}

?>