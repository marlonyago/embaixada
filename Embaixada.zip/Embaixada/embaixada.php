<?php
session_start();

if(!isset($_SESSION["user"])){
        $resp = "Área restrita. favor entrar com LOGIN e SENHA!";
        header("location:index.php?cod=$resp"); 
}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Documento sem título</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/normalize.css">
<link rel="stylesheet" href="assets/css/bootstrap-grid.min.css">
</head>

<body>

    <header>
        
      <div class="user">
         <div class="perfil"></div>  
         <div class="perfil-text">
           <p><?= $_SESSION["user"] ?></p> 
         </div>  
      </div> 
        

   <div class="container">
     <div class="row">
       <div class="col">
           
           <div class="cover-title">
               <div>
                  <h1>type<br>something</h1>
                  <h5>Type something</h5>
                </div>
           </div>
           
           
       </div>  
     </div>    
   </div>     

        
    </header>

<section class="inc">
    <div class="container-fluid" style="padding: 0;">
      <div class="row no-gutters">
        <div class="col">
              
               <nav>
                 <div class="row no-gutters">
                   <div class="col"><div id="tab-1" class="tabs">inscrições</div></div>  
                   <div class="col"><div id="tab-2" class="tabs">lideranças</div></div>  
                 </div> 
               </nav> 
          
        </div>  
      </div>
    </div>
   
</section>
    
    
    
<section class="container">
  <article class="row tab-container">
     
          <div  class="tab-content tab-1">          
              <div class="col-12">
         
          <div class="list-embaixada">
              <div>
                  
               <div class="list-img-embaxada"><img src="assets/Imgens/logo-laranja.png" alt=""></div>
               <div class="text-list-embaxada">
                 <h3>embaixada água verde</h3>
                 <h5>Av. Getulio vargas,3812</h5>
                  <h6>20 Inscrição</h6>
               </div>
                  
              </div>
              
          </div> 
         
     </div>   
          
              <div class="col-12">
              <div class="list-embaixada">
              <div>
                  
               <div class="list-img-embaxada"><img src="assets/Imgens/logo-azul.png" alt=""></div>
               <div class="text-list-embaxada">
                 <h3>embaixada água verde</h3>
                 <h5>Av. Getulio vargas,3812</h5>
                  <h6>20 Inscrição</h6>
               </div>
                  
              </div>
              
          </div>

      </div>
          
              <div class="col-12">
               
         <div class="list-embaixada">
              <div>
                  
               <div class="list-img-embaxada"><img src="assets/Imgens/logo-laranja.png" alt=""></div>
               <div class="text-list-embaxada">
                 <h3>embaixada água verde</h3>
                 <h5>Av. Getulio vargas,3812</h5>
                  <h6>20 Inscrição</h6>
               </div>
                  
              </div>
              
          </div>       
         
      </div>
      
              <div class="col-12">
      <div class="list-embaixada">
              <div>
                  
               <div class="list-img-embaxada"><img src="assets/Imgens/logo-azul.png" alt=""></div>
               <div class="text-list-embaxada">
                 <h3>embaixada água verde</h3>
                 <h5>Av. Getulio vargas,3812</h5>
                  <h6>20 Inscrição</h6>
               </div>
                  
              </div>
              
          </div>
      </div>
          </div>
          
          <div class="tab-content tab-2">          
              <div class="col-12">
         
          <div class="list-embaixada">
              <div>
                  
               <div class="list-img-embaxada"><img src="assets/Imgens/logo-azul.png" alt=""></div>
               <div class="text-list-embaxada">
                 <h3>embaixada água verde</h3>
                 <h5>Av. Getulio vargas,3812</h5>
                  <h6>20 Inscrição</h6>
               </div>
                  
              </div>
              
          </div> 
         
     </div>   
          
              <div class="col-12">
              <div class="list-embaixada">
              <div>
                  
               <div class="list-img-embaxada"><img src="assets/Imgens/logo-laranja.png" alt=""></div>
               <div class="text-list-embaxada">
                 <h3>embaixada água verde</h3>
                 <h5>Av. Getulio vargas,3812</h5>
                  <h6>20 Inscrição</h6>
               </div>
                  
              </div>
              
          </div>

      </div>
          
              <div class="col-12">
               
         <div class="list-embaixada">
              <div>
                  
               <div class="list-img-embaxada"><img src="assets/Imgens/logo-azul.png" alt=""></div>
               <div class="text-list-embaxada">
                 <h3>embaixada água verde</h3>
                 <h5>Av. Getulio vargas,3812</h5>
                  <h6>20 Inscrição</h6>
               </div>
                  
              </div>
              
          </div>       
         
      </div>
      
              <div class="col-12">
      <div class="list-embaixada">
              <div>
                  
               <div class="list-img-embaxada"><img src="assets/Imgens/logo-laranja.png" alt=""></div>
               <div class="text-list-embaxada">
                 <h3>embaixada água verde</h3>
                 <h5>Av. Getulio vargas,3812</h5>
                  <h6>20 Inscrição</h6>
               </div>
                  
              </div>
              
          </div>
      </div>
          </div>
 
  </article>  
</section>  
    
<footer></footer>
    
    
    
    
    
<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
