<?php
    require_once("conecta.php");

    $senha		= md5($_POST['senha']);
	$email		= $_POST['email'];

    $sql = "UPDATE usuarios SET senha='$senha' WHERE email='$email'";
    $ativar = mysqli_query($con,$sql);


    header("location:index.php");

?>