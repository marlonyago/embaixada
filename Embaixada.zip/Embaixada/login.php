<?php
session_start();
require_once("conecta.php");


  $email = $_POST["email"];
  $senha = md5($_POST["senha"]);


    $sql = "SELECT * FROM usuarios WHERE email='$email'";
    $veri = mysqli_query($con,$sql);
    $cont = mysqli_num_rows($veri);
    
    if($cont == 0){
        $resp = "Não a cadastro com esse E-mail, favor se cadastrar";
        header("location:index.php?cod=$resp");

    }else{
       verefica($con,$email,$senha);      
    }
    
function verefica($con,$email,$senha){
    $sql = "SELECT * FROM usuarios WHERE email='$email'";
    $veri = mysqli_query($con,$sql);
    $pega =  mysqli_fetch_array($veri);
    
    if($pega["ativo"] == 0){
        $resp = "Falta você terminar a validação, Favor confirmar seu e-mail";
        header("location:index.php?cod=$resp"); 
    }else{
       logar($con,$email,$senha); 
    }

}
  
function logar($con,$email,$senha){
    
    $sql = "SELECT * FROM usuarios WHERE email='$email' and senha='$senha'";
    $veri = mysqli_query($con,$sql);
    $cont = mysqli_num_rows($veri);
    $acesso = date("Y-m-d H:i:s");  
    
    switch($cont){
        case 1:
                $_SESSION["user"] = $email;
                mysqli_query($con,"UPDATE usuarios SET acesso='$acesso' WHERE email='$email'");
                header("location:embaixada.php");  
        break;
            
        case 0:
        $resp = "E-MAIL ou SENHA incorreto, favor tentar novamente!";
        header("location:index.php?cod=$resp");
        break;
            
        default:
            
        $resp = "Houve um erro ao tentar entrar, favor entrar em contato conosco";
        header("location:index.php?cod=$resp");    
            
    }
    

    
    
}


?>