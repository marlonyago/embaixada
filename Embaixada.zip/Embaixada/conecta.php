<?php

define("local_server","localhost");
define("name_server","root");
define("pass_server","");
define("DB_server","embaixada");


   $con = mysqli_connect(local_server,name_server,pass_server,DB_server);



?>