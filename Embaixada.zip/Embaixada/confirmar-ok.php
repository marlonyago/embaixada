<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Documento sem título</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/normalize.css">
<link rel="stylesheet" href="assets/css/bootstrap-grid.min.css">

</head>
<body class="telas">

	
<div class="container">
  <div class="row">
	  <div class="col">
		  <div class="logo">
	        <img src="assets/Imgens/logo.png" alt="" >
		  </div>
	  </div>  
  </div>	
</div>

    
  <section class="container">
		<article class="row">
	  <div class="col">
		  
	    <div class="login">
		   
            
           
            
 
            
            <div class="ok">
              <h1>Seu cadastro foi executado com sucesso</h1>
              <h2> Favor confirmar em seu email  para poder prosseguir</h2>
            </div> 
            
            
           
            
            
            
		</div>
		  
		  
		  
	  </div>
	</article>
  </section>	


	
<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
