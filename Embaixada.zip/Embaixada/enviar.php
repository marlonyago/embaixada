<?php
require_once("conecta.php");
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

  $nome = $_POST["nome"];
  $email = $_POST["email"];
  $sobrenome = $_POST["sobrenome"];
  $telefone = $_POST["telefone"];
  $senha = md5($_POST["senha"]);
  $cadastro = date("Y-m-d H:i:s");


  $sql_verifica = "SELECT * FROM usuarios WHERE email='$email'";
  $verificar = mysqli_query($con,$sql_verifica);
  $contar = mysqli_num_rows($verificar);

  switch($contar){
    case 1:
      header("location:cadastro.php?cod=1");
    break;
          
    case 0:
      $sql = "INSERT INTO usuarios(nome,sobrenome,email,telefone,senha,cadastro) VALUES('$nome','$sobrenome','$email','$telefone','$senha','$cadastro')";
      $gravar = mysqli_query($con,$sql);
      if($gravar){confirmar($nome,$email);} 
    break;
          
          
      default:
      header("location:cadastro.php?cod=2");
          
  }
  


  //mysqli_error($con);
  function confirmar($nome,$email){
   
      
      
  $urlSite = "http://prof.cd6host.com/Embaixada" ;      
  $emailenviar = $email;
  $destino = $emailenviar;
  $assunto = "Confirmar cadastro";
  $arquivo = "Olá $nome<br/><br/>
			Para confirmar seu cadastro, por favor, clique no link abaixo:<br/>
			<a href='$urlSite/cadastroConfirmado.php?email=$email&nome=$nome'>Clique aqui para confirmar seu cadastro</a><br/><br/>
			Se não tiver sido você ou não desejar confirmar o cadastro, apenas desconsidere esta mensagem<br/><br/>
			Obrigado!";
 

  $headers  = 'MIME-Version: 1.0' . "\r\n";
      $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
      $headers .= 'From: Embaixada <$email>';
  //$headers .= "Bcc: $EmailPadrao\r\n";
   
  $enviaremail = mail($destino, $assunto, $arquivo, $headers);
      
      
  if($enviaremail){
        header("location:confirmar-ok.php");   
  
  } else {
       header("location:confirmar-erro.php"); 
  }
  
      
      
      
  }
  



?>