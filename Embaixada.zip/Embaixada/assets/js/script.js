// Tela carregando

$(window).on('load', function () {
    
   
    $('.load').delay(600).fadeOut('slow'); 
   // $('body').delay(350).css({'overflow': 'visible'});
    
});

//Mascara para o telefone
 $('#telefone').mask('(##) #####-####');

// troca de embaixadas
$('.tab-content').hide();

  $('.tab-content:first').show();

  $('.tabs:first').addClass(' inc-active');

  $('.tabs').click(function(event) {
      
    $('.tabs').removeClass(' inc-active');
      
    $(this).addClass(' inc-active');
      
    $('.tab-content').hide();
      
      

    var selectTab = $(this).attr("id");
      
     
    $("."+selectTab).fadeIn();

  });



//Confirmação de senhas

$("#cadastro").submit(function(event){ 
   var senha = $("#senha").val();
   var senhac = $("#senhac").val();    
    
    if(senha != senhac){
         event.preventDefault();
        
       $("#senhac").css("border-bottom","red 1px solid");  
       $("#senhac").after("<p>Erro: Senhas diferentes!</p>");
        
    }
   

});
