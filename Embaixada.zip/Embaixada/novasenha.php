<?php


	$email		= $_GET['email'];	


?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Documento sem título</title>
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/normalize.css">
<link rel="stylesheet" href="assets/css/bootstrap-grid.min.css">

</head>
<body class="telas">
	
<div class="container">
  <div class="row">
	  <div class="col">
		  <div class="logo">
	        <img src="assets/Imgens/logo.png" alt="" >
		  </div>
	  </div>  
  </div>	
</div>
    
<div class="container">
  <div class="row">
	  <div class="col">
		  <div class="logo">
              
              
    <?php if(isset($_GET["cod"])){ ?>
           <div class="erro"><?= $_GET["cod"]; ?></div>   
    <?php }  ?>
              
              
              
		  </div>
	  </div>  
  </div>	
</div>
    
    
  <section class="container">
		<article class="row">
	  <div class="col">
		  
	    <div class="login">
            <h3>Redefinir Senha</h3>
            <form action="redefinir-senha.php"  method="post">
			 <input type="hidden" value="<?=$email?>" name="email">
			 <input type="password" required placeholder="SENHA" name="senha" id="senha">
			 <input type="password" required placeholder="CONFIRMAR SENHA" name="senhac" id="senhac">
			   
			<button type="submit">Salvar</button>
		   </form> 
		</div>
		  
	  </div>
	</article>
  </section>	


	
<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
